<?php
/*
Plugin Name: Seahouse 4 Businesses
Plugin URI:  http://seahouse.me
Description: Seahouse 4 Businesses lets you add your Business-Data to your site. Google & Co. will love it.
Version:     0.1
Author:      Valentin Seehausen
Author URI:  http://seahouse.me
License:     GPL3
License URI: https://www.gnu.org/licenses/gpl-3.0.html
Domain Path: /languages
Text Domain: seahouse-4-businesses

Seahouse 4 Businesses is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.

Seahouse 4 Businesses is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Seahouse 4 Businesses. If not, see https://www.gnu.org/licenses/gpl-3.0.html.

Have fun and enjoy life.
*/

/******************************
	Register menu
*******************************/
require_once('admin/register-menu.php');


/******************************
	Register Shortcodes
*******************************/
require_once('admin/shortcodes/sc_organization.php');
