# seahouse-4-businesses
Wordpress Plugin that adds Schema Data for Organization and Offers
